package PageRank;

public enum PAGE_RANK_COUNTER {
	RESIDUAL
}
