package PageRankBlocked;

public enum PAGE_RANK_COUNTER {
	RESIDUAL,
	BLOCK_COUNT,
	BLOCK_ITERATION,
	NODE_COUNT,
}
